from main import app  # Import your FastAPI app

# Gunicorn looks for 'application'
application = app
